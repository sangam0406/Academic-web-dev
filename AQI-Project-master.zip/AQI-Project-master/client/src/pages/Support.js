import React from 'react'

const Support = () => {
  return (
    <div className='mt-24 mb-10'>Support</div>
  )
}

export default Support