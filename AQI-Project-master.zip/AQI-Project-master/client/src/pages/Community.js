import React from 'react'

const Community = () => {
  return (
    <div className='mt-24 mb-10'>Community</div>
  )
}

export default Community