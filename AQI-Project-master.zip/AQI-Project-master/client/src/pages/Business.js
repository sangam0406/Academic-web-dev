import React from 'react'

const Business = () => {
  return (
    <div className='mt-24 mb-10'>Business</div>
  )
}

export default Business