import React from 'react'

const AirPurifier = () => {
  return (
    <div className='mt-24 mb-10'>AirPurifier</div>
  )
}

export default AirPurifier