import React from 'react'

const AirQuality = () => {
  return (
    <div className='mt-24 mb-10'>AirQuality</div>
  )
}

export default AirQuality