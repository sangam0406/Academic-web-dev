import React from 'react'

const FaceMask = () => {
  return (
    <div className='mt-24 mb-10'>FaceMask</div>
  )
}

export default FaceMask