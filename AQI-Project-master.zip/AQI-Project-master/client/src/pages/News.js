import React from 'react'

const News = () => {
  return (
    <div className='mt-24 mb-10'>News</div>
  )
}

export default News